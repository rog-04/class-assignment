var x = [];
function setup() {
  createCanvas(400, 400);
  noStroke();
  for (var i = 0; i < 1000; i++) {
	x[i] = random(-1000, 400); 

	}
}

function draw() {
  colorMode(RGB, 255, 255, 255)
  background(7,50,0);
  print(x);
  x[1001] = mouseX;
  for (var i = 0; i < x.length; i++) {

		
		x[i] +=0.5;

		
		var y = i * 0.4;

		fill(18, 120, 0);
		ellipse(x[i], y, 20, 10);
  }
}