function setup() {
  createCanvas(400, 400);
  angleMode(DEGREES);
}

function draw() {
  background(200);
 
  cloud(10, 30);
  cloud(120, 40);
  cloud(190, 25);
  cloud(245, 35);
  cloud(300, 15);
  rotate(180);
  cloud(-100, -125);
}

function cloud(x, y){
  push();
  translate(x, y);
  noStroke();
  ellipse(0,20,50,75)
  ellipse(50,30,75,50)
  ellipse(60, 10, 100, 50)
  ellipse(40, 10, 75, 30)
  
  
  pop();
}