var img;
var img2;
var png;

function preload(){
  img =loadImage("elysium.jpg");
  img2 =loadImage("rex.jpg");
  png =loadImage("aegissword.png");
}
function setup() {
  createCanvas(400, 400);
  textFont("Arial");
}

function draw() {
  background(220);
  
  image(img, 50, 50);
  image(img2, mouseX, mouseY);
  image(png, 200, 200);
  
  textSize(25);
  text("I won't let the world burn a second time!", 10, 50)
  
  
  
  
}